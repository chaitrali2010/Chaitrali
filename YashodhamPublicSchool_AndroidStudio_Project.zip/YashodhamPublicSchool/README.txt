YASHODHAM PUBLIC SCHOOL — ANDROID PROJECT

This is an Android Studio project containing the school-project prototype.
It is not a precompiled APK. Build it in Android Studio to generate the APK.

BUILD STEPS
1. Install Android Studio on a computer.
2. Extract this ZIP.
3. In Android Studio choose: Open, then select the YashodhamPublicSchool folder.
4. Allow Android Studio to sync/download the Android Gradle Plugin and Android SDK
   (the project uses compile SDK 35; install it if prompted).
5. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
6. When complete, click "locate" in the notification.
   The APK is normally at app/build/outputs/apk/debug/app-debug.apk.
7. Transfer the APK to your Android phone and install it. Android may ask you to
   allow installation from that file manager.

PROJECT FEATURES
- Student, Teacher and Parent demo portals
- Class 8 CBSE sample timetable
- Homework checklist and add-homework demo
- Sample attendance and results
- School notices and gallery
- English interface

IMPORTANT
- All names, marks, attendance and notices are sample/demo content.
- This is an offline school-project demonstration, not a live school system.
- It has no real login, server, database, or secure student records.
- Change sample details before presenting if needed.

PACKAGE
com.yashodham.school
